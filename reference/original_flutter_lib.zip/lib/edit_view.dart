import 'package:flutter/material.dart';
import 'model.dart';

class EditView extends StatefulWidget {
  final List<CarEntry> entries;
  final Function(String) onDelete;
  final Function(String, double, double) onUpdate;
  final bool isUrdu;

  const EditView({
    super.key,
    required this.entries,
    required this.onDelete,
    required this.onUpdate,
    required this.isUrdu,
  });

  @override
  State<EditView> createState() => _EditViewState();
}

class _EditViewState extends State<EditView> {
  String _query = "";
  String t(String eng, String urdu) => widget.isUrdu ? urdu : eng;

  @override
  Widget build(BuildContext context) {
    final filtered = widget.entries
        .where((e) => e.total.toString().contains(_query))
        .toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: TextField(
            onChanged: (v) => setState(() => _query = v),
            decoration: InputDecoration(
              hintText: t("Search Price...", "تلاش کریں..."),
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            itemCount: filtered.length,
            itemBuilder: (context, i) => Card(
              margin: const EdgeInsets.all(8),
              child: ListTile(
                title: Text("AED ${filtered[i].total}"),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blue),
                      onPressed: () => _showEdit(filtered[i]),
                    ),
                    // Delete IconButton has been removed from here
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  // _confirm dialog logic removed as it is no longer needed

  void _showEdit(CarEntry item) {
    final m = TextEditingController(text: item.materialCost.toString());
    final l = TextEditingController(text: item.labourCharges.toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: m,
              decoration: InputDecoration(labelText: t("Material", "سامان")),
            ),
            TextField(
              controller: l,
              decoration: InputDecoration(labelText: t("Labour", "مزدوری")),
            ),
          ],
        ),
        actions: [
          ElevatedButton(
            onPressed: () {
              widget.onUpdate(
                item.id,
                double.parse(m.text),
                double.parse(l.text),
              );
              Navigator.pop(ctx);
            },
            child: Text(t("Update", "اپ ڈیٹ")),
          ),
        ],
      ),
    );
  }
}
