import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'model.dart';
import 'dashboard_view.dart';
import 'edit_view.dart';
import 'summary_view.dart';

void main() => runApp(
  const MaterialApp(home: MainLayout(), debugShowCheckedModeBanner: false),
);

class MainLayout extends StatefulWidget {
  const MainLayout({super.key});
  @override
  State<MainLayout> createState() => _MainLayoutState();
}

class _MainLayoutState extends State<MainLayout> {
  int _activePage = 0;
  bool _isUrdu = false;
  double _monthlyGoal = 10000.0;
  List<CarEntry> _entries = [];
  List<ExpenseEntry> _expenses = [];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _entries = (json.decode(prefs.getString('cars') ?? '[]') as List)
          .map((e) => CarEntry.fromMap(e))
          .toList();
      _expenses = (json.decode(prefs.getString('exps') ?? '[]') as List)
          .map((e) => ExpenseEntry.fromMap(e))
          .toList();
      _monthlyGoal = prefs.getDouble('monthlyGoal') ?? 10000.0;
    });
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      'cars',
      json.encode(_entries.map((e) => e.toMap()).toList()),
    );
    await prefs.setString(
      'exps',
      json.encode(_expenses.map((e) => e.toMap()).toList()),
    );
  }

  Future<void> _updateTarget(double newTarget) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _monthlyGoal = newTarget);
    await prefs.setDouble('monthlyGoal', newTarget);
  }

  @override
  Widget build(BuildContext context) {
    bool isDesktop = MediaQuery.of(context).size.width > 800;

    return Directionality(
      textDirection: _isUrdu ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        backgroundColor: const Color(0xFFF1F5F9),
        appBar: AppBar(
          backgroundColor: const Color(0xFF334155),
          elevation: 0,
          title: isDesktop
              ? const Text(
                  "AutoWorkshop Pro",
                  style: TextStyle(
                    color: Color(0xFF38BDF8),
                    fontWeight: FontWeight.bold,
                  ),
                )
              : null,
          actions: [
            TextButton.icon(
              onPressed: () => setState(() => _isUrdu = !_isUrdu),
              icon: const Icon(Icons.language, color: Colors.white, size: 18),
              label: Text(
                _isUrdu ? "UR" : "EN",
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                  fontSize: 14,
                ),
              ),
            ),
            const VerticalDivider(
              color: Colors.white24,
              indent: 15,
              endIndent: 15,
            ),
            _navBtn(_isUrdu ? "نیا اندراج" : "New Entry", 0),
            _navBtn(_isUrdu ? "ایڈٹ" : "Edit", 1),
            _navBtn(_isUrdu ? "خلاصہ" : "Summary", 2),
            const SizedBox(width: 10),
          ],
        ),
        body: IndexedStack(
          index: _activePage,
          children: [
            DashboardView(
              isUrdu: _isUrdu,
              entries: _entries,
              expenses: _expenses,
              onSaveCar: (c) {
                setState(() {
                  // CHECK IF RECORD EXISTS
                  int index = _entries.indexWhere((e) => e.id == c.id);
                  if (index != -1) {
                    // UPDATE OLD ONE
                    _entries[index] = c;
                  } else {
                    // SAVE NEW ONE
                    _entries.insert(0, c);
                  }
                });
                _save();
              },
              onSaveExp: (e) {
                setState(() => _expenses.insert(0, e));
                _save();
              },
              onDeleteExp: (id) {
                setState(() => _expenses.removeWhere((x) => x.id == id));
                _save();
              },
            ),
            EditView(
              isUrdu: _isUrdu,
              entries: _entries,
              onDelete: (id) {
                setState(() => _entries.removeWhere((x) => x.id == id));
                _save();
              },
              onUpdate: (id, m, l) {
                setState(() {
                  var item = _entries.firstWhere((e) => e.id == id);
                  item.materialCost = m;
                  item.labourCharges = l;
                });
                _save();
              },
            ),
            SummaryView(
              isUrdu: _isUrdu,
              entries: _entries,
              expenses: _expenses,
              monthlyGoal: _monthlyGoal,
              onTargetChanged: _updateTarget,
            ),
          ],
        ),
      ),
    );
  }

  Widget _navBtn(String label, int idx) => TextButton(
    onPressed: () => setState(() => _activePage = idx),
    child: Text(
      label,
      style: TextStyle(
        color: _activePage == idx ? const Color(0xFF38BDF8) : Colors.white,
        fontWeight: _activePage == idx ? FontWeight.bold : FontWeight.normal,
      ),
    ),
  );
}
