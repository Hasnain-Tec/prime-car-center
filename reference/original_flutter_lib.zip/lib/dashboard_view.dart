import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';
import 'model.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

class DashboardView extends StatefulWidget {
  final List<CarEntry> entries;
  final List<ExpenseEntry> expenses;
  final Function(CarEntry) onSaveCar;
  final Function(ExpenseEntry) onSaveExp;
  final Function(String) onDeleteExp;
  final bool isUrdu;

  const DashboardView({
    super.key,
    required this.entries,
    required this.expenses,
    required this.onSaveCar,
    required this.onSaveExp,
    required this.onDeleteExp,
    required this.isUrdu,
  });

  @override
  State<DashboardView> createState() => _DashboardViewState();
}

class _DashboardViewState extends State<DashboardView> {
  final _mat = TextEditingController();
  final _lab = TextEditingController();
  final _amt = TextEditingController();
  final _cat = TextEditingController();
  final _searchQuery = TextEditingController();
  final _plate = TextEditingController();
  final _desc = TextEditingController();

  File? _image;
  String? _editingId;
  DateTime? _editingDate;
  final picker = ImagePicker();

  String t(String eng, String urdu) => widget.isUrdu ? urdu : eng;

  @override
  void initState() {
    super.initState();
    _searchQuery.addListener(() => setState(() {}));
  }

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await picker.pickImage(source: source);
    if (pickedFile != null) setState(() => _image = File(pickedFile.path));
  }

  void _editRecord(CarEntry entry) {
    setState(() {
      _editingId = entry.id;
      _editingDate = entry.date;
      _mat.text = entry.materialCost == 0
          ? ""
          : entry.materialCost.toInt().toString();
      _lab.text = entry.labourCharges == 0
          ? ""
          : entry.labourCharges.toInt().toString();
      _plate.text = entry.plateNumber ?? "";
      _desc.text = entry.description ?? "";
      _image = entry.imagePath != null ? File(entry.imagePath!) : null;
    });
  }

  void _resetForm() {
    setState(() {
      _editingId = null;
      _editingDate = null;
      _mat.clear();
      _lab.clear();
      _plate.clear();
      _desc.clear();
      _image = null;
    });
  }

  void _handleSaveExpense() {
    if (_amt.text.isEmpty) return;
    final isNumeric = double.tryParse(_cat.text) != null;
    if (isNumeric && _cat.text.isNotEmpty) {
      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: Text(t("Confirmation", "تصدیق")),
          content: Text(
            t("Save numeric description?", "کیا آپ اسے محفوظ کرنا چاہتے ہیں؟"),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: Text(t("Cancel", "منسوخ")),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(ctx);
                _submitExpense();
              },
              child: Text(t("Save", "محفوظ")),
            ),
          ],
        ),
      );
    } else {
      _submitExpense();
    }
  }

  void _submitExpense() {
    widget.onSaveExp(
      ExpenseEntry(
        id: DateTime.now().toString(),
        amount: double.tryParse(_amt.text) ?? 0,
        category: _cat.text,
        date: DateTime.now(),
      ),
    );
    _amt.clear();
    _cat.clear();
    setState(() {});
  }

  // --- 1. SINGLE RECEIPT WITH IMAGE & DESCRIPTION ---
  Future<void> _generateSingleReceipt(CarEntry entry) async {
    final pdf = pw.Document();
    pw.MemoryImage? carImage;
    if (entry.imagePath != null && File(entry.imagePath!).existsSync()) {
      carImage = pw.MemoryImage(File(entry.imagePath!).readAsBytesSync());
    }

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a5,
        build: (context) => pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            pw.Center(
              child: pw.Text(
                "WORKSHOP RECEIPT",
                style: pw.TextStyle(
                  fontSize: 18,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
            pw.Divider(),
            pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text("Date: ${entry.date.toString().substring(0, 16)}"),
                pw.Text(
                  "Plate: ${entry.plateNumber ?? 'N/A'}",
                  style: pw.TextStyle(fontWeight: pw.FontWeight.bold),
                ),
              ],
            ),
            pw.SizedBox(height: 10),
            if (carImage != null)
              pw.Container(
                height: 120,
                width: double.infinity,
                child: pw.Center(
                  child: pw.Image(carImage, fit: pw.BoxFit.contain),
                ),
              ),
            pw.SizedBox(height: 10),
            pw.Text(
              "Work Description:",
              style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 10),
            ),
            pw.Text(
              entry.description ?? "N/A",
              style: const pw.TextStyle(fontSize: 10),
            ),
            pw.SizedBox(height: 15),
            pw.TableHelper.fromTextArray(
              data: [
                ['Item', 'Amount'],
                ['Material', 'AED ${entry.materialCost.toInt()}'],
                ['Labour', 'AED ${entry.labourCharges.toInt()}'],
              ],
            ),
            pw.SizedBox(height: 15),
            pw.Align(
              alignment: pw.Alignment.centerRight,
              child: pw.Text(
                "Total: AED ${entry.total.toInt()}",
                style: pw.TextStyle(
                  fontSize: 16,
                  fontWeight: pw.FontWeight.bold,
                ),
              ),
            ),
          ],
        ),
      ),
    );
    await Printing.layoutPdf(onLayout: (format) async => pdf.save());
  }

  // --- 2. MULTI-RECORD REPORT (DAILY/WEEKLY/MONTHLY) WITH IMAGES & DESCRIPTION ---
  Future<void> _generatePeriodPdf(
    String title,
    List<CarEntry> filteredEntries,
  ) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape, // Landscape for wide tables
        build: (context) => [
          pw.Header(level: 0, child: pw.Text("Workshop Report - $title")),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey300),
            columnWidths: {
              0: const pw.FixedColumnWidth(60), // Date
              1: const pw.FixedColumnWidth(60), // Plate
              2: const pw.FixedColumnWidth(80), // Photo
              3: const pw.FlexColumnWidth(2), // Description
              4: const pw.FixedColumnWidth(50), // Mat
              5: const pw.FixedColumnWidth(50), // Lab
              6: const pw.FixedColumnWidth(60), // Total
            },
            children: [
              // Header Row
              pw.TableRow(
                decoration: const pw.BoxDecoration(
                  color: PdfColors.blueGrey900,
                ),
                children:
                    [
                          'Date',
                          'Plate',
                          'Photo',
                          'Work Description',
                          'Mat.',
                          'Lab.',
                          'Total',
                        ]
                        .map(
                          (text) => pw.Padding(
                            padding: const pw.EdgeInsets.all(5),
                            child: pw.Text(
                              text,
                              style: pw.TextStyle(
                                color: PdfColors.white,
                                fontWeight: pw.FontWeight.bold,
                                fontSize: 10,
                              ),
                            ),
                          ),
                        )
                        .toList(),
              ),
              // Data Rows
              ...filteredEntries.map((e) {
                pw.MemoryImage? rowImg;
                if (e.imagePath != null && File(e.imagePath!).existsSync()) {
                  rowImg = pw.MemoryImage(File(e.imagePath!).readAsBytesSync());
                }
                return pw.TableRow(
                  verticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: [
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.date.toString().substring(5, 10),
                        style: const pw.TextStyle(fontSize: 9),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.plateNumber ?? "-",
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 9,
                        ),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(2),
                      child: rowImg != null
                          ? pw.Container(
                              height: 40,
                              width: 40,
                              child: pw.Image(rowImg, fit: pw.BoxFit.cover),
                            )
                          : pw.Text(
                              "No Photo",
                              style: const pw.TextStyle(
                                fontSize: 8,
                                color: PdfColors.grey,
                              ),
                            ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.description ?? "-",
                        style: const pw.TextStyle(fontSize: 9),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.materialCost.toInt()}",
                        style: const pw.TextStyle(fontSize: 9),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.labourCharges.toInt()}",
                        style: const pw.TextStyle(fontSize: 9),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.total.toInt()}",
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 9,
                        ),
                      ),
                    ),
                  ],
                );
              }),
            ],
          ),
        ],
      ),
    );
    await Printing.layoutPdf(onLayout: (format) async => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    double dayRev = widget.entries
        .where((e) => e.date.day == now.day && e.date.month == now.month)
        .fold(0, (sum, e) => sum + e.total);
    double weekRev = widget.entries
        .where((e) => now.difference(e.date).inDays <= 7)
        .fold(0, (sum, e) => sum + e.total);
    double monthRev = widget.entries
        .where((e) => now.difference(e.date).inDays <= 30)
        .fold(0, (sum, e) => sum + e.total);

    final filteredList = widget.entries.where((e) {
      final query = _searchQuery.text.toLowerCase();
      return (e.plateNumber?.toLowerCase().contains(query) ?? false) ||
          e.total.toString().contains(query);
    }).toList();

    bool isMobile = MediaQuery.of(context).size.width < 800;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          if (isMobile) ...[
            _carSection(),
            const SizedBox(height: 20),
            _expSection(),
          ] else ...[
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(flex: 2, child: _carSection()),
                const SizedBox(width: 20),
                Expanded(flex: 1, child: _expSection()),
              ],
            ),
          ],
          const SizedBox(height: 25),
          isMobile
              ? Column(children: _sumGroup(dayRev, weekRev, monthRev))
              : Row(
                  children: _sumGroup(dayRev, weekRev, monthRev)
                      .map(
                        (e) => Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 5),
                            child: e,
                          ),
                        ),
                      )
                      .toList(),
                ),
          const SizedBox(height: 25),
          _whiteCard(
            t("Recent Records", "حالیہ ریکارڈ"),
            Column(
              children: [
                TextField(
                  controller: _searchQuery,
                  decoration: InputDecoration(
                    hintText: t(
                      "Search Plate or Price...",
                      "پلیٹ نمبر یا رقم تلاش کریں",
                    ),
                    prefixIcon: const Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
                const SizedBox(height: 15),
                ...filteredList.take(20).map((e) => _recentTile(e)).toList(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _carSection() => _whiteCard(
    _editingId == null
        ? t("New Car Entry", "نئی گاڑی کا اندراج")
        : t("Edit Record", "ترمیم کریں"),
    Column(
      children: [
        _imgBox(),
        const SizedBox(height: 15),
        Wrap(
          spacing: 8,
          children: [
            _pBtn(
              Icons.camera_alt,
              t("Photo", "تصویر"),
              () => _pickImage(ImageSource.camera),
            ),
            _pBtn(
              Icons.image,
              t("Gallery", "گیلری"),
              () => _pickImage(ImageSource.gallery),
            ),
            if (_editingId != null)
              _pBtn(Icons.cancel, t("Cancel", "منسوخ"), _resetForm),
          ],
        ),
        const SizedBox(height: 20),
        _inp(t("Plate Number", "پلیٹ نمبر"), _plate, false),
        const SizedBox(height: 15),
        _inp(t("Work Description", "کام کی تفصیل"), _desc, false),
        const SizedBox(height: 15),
        Row(
          children: [
            Expanded(child: _inp(t("Material", "سامان"), _mat, true)),
            const SizedBox(width: 10),
            Expanded(child: _inp(t("Labour", "مزدوری"), _lab, true)),
          ],
        ),
        const SizedBox(height: 20),
        _gBtn(
          _editingId == null
              ? t("Save Entry", "محفوظ کریں")
              : t("Update Entry", "اپ ڈیٹ کریں"),
          () {
            if (_mat.text.isEmpty &&
                _lab.text.isEmpty &&
                _image == null &&
                _plate.text.isEmpty)
              return;
            widget.onSaveCar(
              CarEntry(
                id: _editingId ?? DateTime.now().toString(),
                plateNumber: _plate.text,
                description: _desc.text,
                materialCost: double.tryParse(_mat.text) ?? 0,
                labourCharges: double.tryParse(_lab.text) ?? 0,
                date: _editingDate ?? DateTime.now(),
                imagePath: _image?.path,
              ),
            );
            _resetForm();
          },
        ),
      ],
    ),
  );

  Widget _expSection() {
    final now = DateTime.now();
    final todaysExpenses = widget.expenses
        .where((e) => e.date.day == now.day && e.date.month == now.month)
        .toList();

    return _whiteCard(
      t("Expenses", "اخراجات"),
      Column(
        children: [
          _inp(t("Amount", "رقم"), _amt, true),
          const SizedBox(height: 10),
          _inp(t("Description", "تفصیل"), _cat, false),
          const SizedBox(height: 15),
          _gBtn(t("Save", "محفوظ"), _handleSaveExpense),
          if (todaysExpenses.isNotEmpty) ...[
            const Divider(height: 30),
            Align(
              alignment: Alignment.centerLeft,
              child: Text(
                t("Today's Expenses", "آج کے اخراجات"),
                style: const TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: Colors.grey,
                ),
              ),
            ),
            const SizedBox(height: 10),
            ...todaysExpenses.map(
              (e) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(e.category.isEmpty ? t("General", "عام") : e.category),
                    Text(
                      "AED ${e.amount.toInt()}",
                      style: const TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  List<Widget> _sumGroup(double d, double w, double m) {
    final now = DateTime.now();
    return [
      _sumTile(
        t("Day", "آج"),
        d,
        const Color(0xFF38BDF8),
        true,
        () => _generatePeriodPdf(
          "Daily",
          widget.entries.where((e) => e.date.day == now.day).toList(),
        ),
      ),
      const SizedBox(height: 10, width: 10),
      _sumTile(
        t("Week", "ہفتہ"),
        w,
        Colors.white,
        false,
        () => _generatePeriodPdf(
          "Weekly",
          widget.entries
              .where((e) => now.difference(e.date).inDays <= 7)
              .toList(),
        ),
      ),
      const SizedBox(height: 10, width: 10),
      _sumTile(
        t("Month", "مہینہ"),
        m,
        Colors.white,
        false,
        () => _generatePeriodPdf(
          "Monthly",
          widget.entries
              .where((e) => now.difference(e.date).inDays <= 30)
              .toList(),
        ),
      ),
    ];
  }

  Widget _sumTile(String l, double v, Color b, bool iB, VoidCallback tap) =>
      GestureDetector(
        onTap: tap,
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: b,
            borderRadius: BorderRadius.circular(12),
            border: iB ? null : Border.all(color: Colors.grey[200]!),
            boxShadow: [
              if (!iB) const BoxShadow(color: Colors.black12, blurRadius: 4),
            ],
          ),
          child: Column(
            children: [
              Text(
                l,
                style: TextStyle(
                  color: iB ? Colors.white70 : Colors.grey,
                  fontSize: 12,
                ),
              ),
              Text(
                "AED ${v.toInt()}",
                style: TextStyle(
                  color: iB ? Colors.white : Colors.red,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Icon(Icons.print, size: 12, color: Colors.grey),
            ],
          ),
        ),
      );

  Widget _recentTile(CarEntry c) {
    bool isBeingEdited = _editingId == c.id;
    return ListTile(
      onTap: () => _editRecord(c),
      tileColor: isBeingEdited ? Colors.blue.withOpacity(0.05) : null,
      leading: c.imagePath != null
          ? ClipRRect(
              borderRadius: BorderRadius.circular(5),
              child: Image.file(
                File(c.imagePath!),
                width: 40,
                height: 40,
                fit: BoxFit.cover,
              ),
            )
          : const Icon(Icons.car_repair),
      title: Text(
        c.plateNumber?.isEmpty ?? true ? "No Plate" : c.plateNumber!,
        style: const TextStyle(fontWeight: FontWeight.bold),
      ),
      subtitle: Text(
        "AED ${c.total.toInt()} - ${c.date.toString().substring(11, 16)}",
      ),
      trailing: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          IconButton(
            icon: const Icon(Icons.print, color: Colors.blue, size: 20),
            onPressed: () => _generateSingleReceipt(c),
          ),
          Icon(
            isBeingEdited ? Icons.edit_note : Icons.edit,
            color: isBeingEdited ? Colors.blue : Colors.grey[400],
            size: 20,
          ),
        ],
      ),
    );
  }

  Widget _imgBox() => Container(
    height: 160,
    width: double.infinity,
    decoration: BoxDecoration(
      color: Colors.grey[100],
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Colors.grey[300]!),
    ),
    child: _image == null
        ? const Icon(Icons.image_outlined)
        : ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(_image!, fit: BoxFit.cover),
          ),
  );

  Widget _pBtn(IconData i, String l, VoidCallback tap) => ElevatedButton.icon(
    onPressed: tap,
    icon: Icon(i, size: 14),
    label: Text(l, style: const TextStyle(fontSize: 11)),
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF334155),
      foregroundColor: Colors.white,
      shape: const StadiumBorder(),
    ),
  );

  Widget _gBtn(String l, VoidCallback tap) => ElevatedButton(
    onPressed: tap,
    style: ElevatedButton.styleFrom(
      backgroundColor: const Color(0xFF22C55E),
      minimumSize: const Size(double.infinity, 50),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
    ),
    child: Text(
      l,
      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
    ),
  );

  Widget _inp(String l, TextEditingController c, bool n) => TextField(
    controller: c,
    keyboardType: n ? TextInputType.number : TextInputType.text,
    decoration: InputDecoration(
      labelText: l,
      border: const OutlineInputBorder(),
      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
    ),
  );

  Widget _whiteCard(String t, Widget c) => Container(
    padding: const EdgeInsets.all(16),
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(15),
      boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10),
      ],
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          t,
          style: const TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: Color(0xFF334155),
          ),
        ),
        const Divider(height: 20),
        c,
      ],
    ),
  );
}
