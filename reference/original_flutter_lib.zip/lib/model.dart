class CarEntry {
  String id;
  double materialCost;
  double labourCharges;
  DateTime date;
  String? imagePath;
  String? plateNumber;
  String? description; // Added this

  CarEntry({
    required this.id,
    required this.materialCost,
    required this.labourCharges,
    required this.date,
    this.imagePath,
    this.plateNumber,
    this.description, // Added this
  });

  double get total => materialCost + labourCharges;

  Map<String, dynamic> toMap() => {
    'id': id,
    'materialCost': materialCost,
    'labourCharges': labourCharges,
    'date': date.toIso8601String(),
    'imagePath': imagePath,
    'plateNumber': plateNumber,
    'description': description, // Added this
  };

  factory CarEntry.fromMap(Map<String, dynamic> map) => CarEntry(
    id: map['id'],
    materialCost: map['materialCost'],
    labourCharges: map['labourCharges'],
    date: DateTime.parse(map['date']),
    imagePath: map['imagePath'],
    plateNumber: map['plateNumber'],
    description: map['description'], // Added this
  );
}

class ExpenseEntry {
  String id;
  double amount;
  String category;
  DateTime date;

  ExpenseEntry({
    required this.id,
    required this.amount,
    required this.category,
    required this.date,
  });

  Map<String, dynamic> toMap() => {
    'id': id,
    'amount': amount,
    'category': category,
    'date': date.toIso8601String(),
  };

  factory ExpenseEntry.fromMap(Map<String, dynamic> map) => ExpenseEntry(
    id: map['id'],
    amount: map['amount'],
    category: map['category'],
    date: DateTime.parse(map['date']),
  );
}
