import 'package:flutter/material.dart';
import 'model.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'dart:io';

class SummaryView extends StatelessWidget {
  final List<CarEntry> entries;
  final List<ExpenseEntry> expenses;
  final bool isUrdu;
  final double monthlyGoal;
  final Function(double) onTargetChanged;

  const SummaryView({
    super.key,
    required this.entries,
    required this.expenses,
    required this.isUrdu,
    required this.monthlyGoal,
    required this.onTargetChanged,
  });

  String t(String eng, String urdu) => isUrdu ? urdu : eng;

  Future<void> _generatePdf() async {
    final pdf = pw.Document();

    double totalLabour = entries.fold(0, (sum, e) => sum + e.labourCharges);
    double totalExp = expenses.fold(0, (sum, e) => sum + e.amount);
    double netProfit = totalLabour - totalExp;

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4.landscape,
        build: (context) => [
          pw.Header(
            level: 0,
            child: pw.Row(
              mainAxisAlignment:
                  pw.MainAxisAlignment.spaceBetween, // Correctly uses pw prefix
              children: [
                pw.Text("Workshop Business Summary Report"),
                pw.Text(DateTime.now().toString().substring(0, 10)),
              ],
            ),
          ),
          pw.Divider(),
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text("Total Labour (Earnings): AED ${totalLabour.toInt()}"),
              pw.Text("Shop Expenses: AED ${totalExp.toInt()}"),
              pw.Text(
                "Net Profit: AED ${netProfit.toInt()}",
                style: pw.TextStyle(
                  fontWeight: pw.FontWeight.bold,
                  color: netProfit >= 0 ? PdfColors.green : PdfColors.red,
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 10),
          pw.Table(
            border: pw.TableBorder.all(color: PdfColors.grey400),
            columnWidths: {
              0: const pw.FixedColumnWidth(60),
              1: const pw.FixedColumnWidth(70),
              2: const pw.FixedColumnWidth(50),
              3: const pw.FlexColumnWidth(2),
              4: const pw.FixedColumnWidth(50),
              5: const pw.FixedColumnWidth(50),
              6: const pw.FixedColumnWidth(60),
            },
            children: [
              pw.TableRow(
                decoration: const pw.BoxDecoration(
                  color: PdfColors.blueGrey900,
                ),
                children:
                    [
                          'Date',
                          'Plate',
                          'Photo',
                          'Work Description',
                          'Mat.',
                          'Lab.',
                          'Total',
                        ]
                        .map(
                          (text) => pw.Padding(
                            padding: const pw.EdgeInsets.all(5),
                            child: pw.Text(
                              text,
                              style: pw.TextStyle(
                                color: PdfColors.white,
                                fontWeight: pw.FontWeight.bold,
                                fontSize: 9,
                              ),
                            ),
                          ),
                        )
                        .toList(),
              ),
              ...entries.map((e) {
                pw.MemoryImage? rowImg;
                if (e.imagePath != null && File(e.imagePath!).existsSync()) {
                  rowImg = pw.MemoryImage(File(e.imagePath!).readAsBytesSync());
                }
                return pw.TableRow(
                  verticalAlignment: pw.TableCellVerticalAlignment.middle,
                  children: [
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.date.toString().substring(5, 10),
                        style: const pw.TextStyle(fontSize: 8),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.plateNumber ?? "-",
                        style: pw.TextStyle(
                          fontWeight: pw.FontWeight.bold,
                          fontSize: 8,
                        ),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(2),
                      child: rowImg != null
                          ? pw.Container(
                              height: 30,
                              width: 30,
                              child: pw.Image(rowImg, fit: pw.BoxFit.cover),
                            )
                          : pw.Text(
                              "No Photo",
                              style: const pw.TextStyle(
                                fontSize: 6,
                                color: PdfColors.grey,
                              ),
                            ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        e.description ?? "-",
                        style: const pw.TextStyle(fontSize: 8),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.materialCost.toInt()}",
                        style: const pw.TextStyle(fontSize: 8),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.labourCharges.toInt()}",
                        style: pw.TextStyle(
                          fontSize: 8,
                          fontWeight: pw.FontWeight.bold,
                        ),
                      ),
                    ),
                    pw.Padding(
                      padding: const pw.EdgeInsets.all(5),
                      child: pw.Text(
                        "${e.total.toInt()}",
                        style: const pw.TextStyle(fontSize: 8),
                      ),
                    ),
                  ],
                );
              }),
            ],
          ),
        ],
      ),
    );

    await Printing.layoutPdf(onLayout: (format) async => pdf.save());
  }

  @override
  Widget build(BuildContext context) {
    double totalRev = entries.fold(0, (sum, e) => sum + e.total);
    double totalLabour = entries.fold(0, (sum, e) => sum + e.labourCharges);
    double totalExp = expenses.fold(0, (sum, e) => sum + e.amount);
    double netProfit = totalLabour - totalExp;
    double prog = monthlyGoal > 0
        ? (totalLabour / monthlyGoal).clamp(0.0, 1.0)
        : 0.0;

    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: const Color(0xFF334155),
              borderRadius: BorderRadius.circular(15),
            ),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment
                      .spaceBetween, // Correctly uses Flutter version (no pw.)
                  children: [
                    Text(
                      t("Earnings Target (Labour)", "مزدوری کا ہدف"),
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 12,
                      ),
                    ),
                    IconButton(
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.blue,
                        size: 18,
                      ),
                      onPressed: () => _showTarget(context),
                    ),
                  ],
                ),
                Text(
                  "AED ${monthlyGoal.toInt()}",
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 10),
                LinearProgressIndicator(
                  value: prog,
                  backgroundColor: Colors.white10,
                  color: Colors.green,
                  minHeight: 8,
                ),
                const SizedBox(height: 5),
                Text(
                  "${(prog * 100).toInt()}% ${t("Done", "مکمل")}",
                  style: const TextStyle(color: Colors.white60, fontSize: 12),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _stat(
            t("Total Revenue", "کل آمدنی"),
            totalRev,
            Colors.blue,
            Icons.account_balance_wallet,
          ),
          _stat(
            t("Labour Earned", "کل مزدوری"),
            totalLabour,
            Colors.green,
            Icons.handyman,
          ),
          _stat(
            t("Shop Expenses", "کل اخراجات"),
            totalExp,
            Colors.orange,
            Icons.trending_down,
          ),
          const SizedBox(height: 10),
          const Divider(),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(15),
            decoration: BoxDecoration(
              color: netProfit >= 0
                  ? Colors.green.withOpacity(0.1)
                  : Colors.red.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: netProfit >= 0 ? Colors.green : Colors.red,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment
                  .spaceBetween, // Correctly uses Flutter version (no pw.)
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      netProfit >= 0
                          ? t("Net Profit", "خالص منافع")
                          : t("Net Loss", "خالص نقصان"),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: netProfit >= 0
                            ? Colors.green[800]
                            : Colors.red[800],
                      ),
                    ),
                    Text(
                      t("Labour - Expenses", "مزدوری منفی اخراجات"),
                      style: TextStyle(
                        fontSize: 11,
                        color: netProfit >= 0 ? Colors.green : Colors.red,
                      ),
                    ),
                  ],
                ),
                Text(
                  "AED ${netProfit.toInt()}",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: netProfit >= 0 ? Colors.green[800] : Colors.red[800],
                  ),
                ),
              ],
            ),
          ),
          const Spacer(),
          ElevatedButton.icon(
            onPressed: _generatePdf,
            icon: const Icon(Icons.picture_as_pdf),
            label: Text(
              t("Download Detailed Report", "تفصیلی رپورٹ ڈاؤن لوڈ کریں"),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.redAccent,
              foregroundColor: Colors.white,
              minimumSize: const Size(double.infinity, 50),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showTarget(BuildContext context) {
    final c = TextEditingController(text: monthlyGoal.toString());
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(t("Set Monthly Target", "ماہانہ ہدف مقرر کریں")),
        content: TextField(controller: c, keyboardType: TextInputType.number),
        actions: [
          ElevatedButton(
            onPressed: () {
              onTargetChanged(double.tryParse(c.text) ?? 0.0);
              Navigator.pop(ctx);
            },
            child: Text(t("Save", "محفوظ")),
          ),
        ],
      ),
    );
  }

  Widget _stat(String l, double v, Color c, IconData icon) => Container(
    margin: const EdgeInsets.only(bottom: 10),
    decoration: BoxDecoration(
      color: Colors.white,
      borderRadius: BorderRadius.circular(12),
      boxShadow: [
        BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 5),
      ],
    ),
    child: ListTile(
      leading: Icon(icon, color: c),
      title: Text(l, style: const TextStyle(fontWeight: FontWeight.w500)),
      trailing: Text(
        "AED ${v.toInt()}",
        style: TextStyle(color: c, fontWeight: FontWeight.bold, fontSize: 16),
      ),
    ),
  );
}
